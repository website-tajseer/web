# Current sitemap

EXISTING FACTS — one observed URL, https://tajseerksa.com/

```text
/ (English default observed; Arabic toggled in-place)
├── Home — hero video (id=Home)
├── About us (id=About)
│   ├── Company profile
│   ├── Mission
│   ├── Vision
│   └── YouTube video
├── Services (id=Service)
│   ├── Interactive Multimedia
│   ├── Elearning Courses Development
│   ├── STEM Methodology
│   ├── AR and VR Environments
│   └── Training and Consulting
├── Education / Technology / Thinking banners (id=Consulting)
└── Contact/footer — map, telephone, email, copyright
```

Header/menu: Home, About us, Service, AR/EN. No dedicated Contact navigation item. Mobile overlay additionally contains map, email and v 1.0.1. Header navigation href values are all /; the observed service click scrolls without changing URL. No service-detail routes were discovered. #Home, #About and #Service identify DOM sections; deep-link initialization was not established.

# Homepage strategy

RECOMMENDED narrative: establish relevance, expose capabilities, explain identity, support trust, invite contact.

1. **Text-led hero:** Who Tajseer is and what it offers. Educational content and technology, not an unexplained technology video. Primary: Discuss your learning needs. Secondary: Explore services.
2. **Five service areas:** Show actual offering breadth early. Each card has a visible, specific summary and service link. This answers what the visitor can buy without hovering.
3. **Company and Saudi context:** Brief profile and the existing 2009 statement once confirmed. Explain institutional learning focus; link to mission/vision on About rather than placing two dense paragraphs at the top.
4. **How the capabilities relate:** Explain content, interactive experiences and consultancy using the verified service scope. Do not assert a proprietary process, team size or superiority.
5. **Approved evidence — conditional:** One concrete project/sample with Tajseer’s role is more useful than an unsubstantiated client-logo strip. Omit until supplied. Why trust Tajseer and what makes it different remain partly unanswered until evidence arrives.
6. **Contact invitation:** Ask for learning needs and offer confirmed public channels. Repeat contact action near the end.
7. **Footer:** Navigation, service links, Arabic/English switch, verified contacts and approved copyright/privacy links.

This answers audience fit using institutions and technical/vocational learning contexts supported by the source. Additional buyer segments remain INFERRED. No statistics, certifications or generic “leading company” claims should fill evidence gaps. Keep technology illustrations secondary to actual learning work. On mobile, hero text and first service options should appear without long video or animation delays.

# Future component inventory — PROPOSED

| Component | Content / use | Required behavior and states | Readiness |
|---|---|---|---|
| Header / brand lockup | Approved logo, navigation | LTR/RTL, sticky if justified, contrasting background | Logo approval needed |
| Desktop navigation | Home/About/Services/Contact | Keyboard/click service expansion, current page, visible focus | IA proposed |
| Mobile navigation | Same destinations and language switch | Open/closed, labelled toggle, Escape, focus trap/return | Must be tested later |
| Language switch | العربية / English | Preserve equivalent page; correct lang/dir | Full bilingual drafts require approval |
| Hero | Headline, support, 1–2 CTAs | Text remains visible independent of media | Draft copy ready |
| Section header | Heading and short introduction | Logical heading level, flexible text length | Ready for design |
| Service card | Name, summary, image, link | Visible summary; focus/hover; no flip dependency | Five source-backed drafts |
| Service detail sections | Scope, methods, conditional sample | Normal flow; optional related service links | Scope confirmation needed |
| Company / mission block | Profile, mission, vision | Balanced reading widths in both scripts | Editorial approval needed |
| Media block | Image/video, caption | Poster, controls, transcript/captions, reduced motion | Rights/content review needed |
| Evidence/project block | Approved case, role, result | Entire block omitted if absent | BUSINESS INPUT REQUIRED |
| CTA banner | Contextual enquiry | Consistent destination, clear focus | Channel confirmation needed |
| Contact details | Map, email, phones | tel/mailto links; bidi isolation | Phone/email approval needed |
| Contact form — optional | Approved minimal fields | Empty, invalid, sending, success, failure; privacy text | Operational decision required |
| Footer | Links, contacts, copyright | Responsive, semantic | Confirm legal text |

Do not add Stats, Testimonials or Client Logos components to launch scope without actual approved data. A reusable empty card is not a reason to invent a content section. CMS model (future): page, locale, section, service, asset, source, approval status and optional evidence reference. This is component planning only.

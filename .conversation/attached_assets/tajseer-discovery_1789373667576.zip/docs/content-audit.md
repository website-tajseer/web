# Content audit

Original wording is preserved before all proposed copy. Source: https://tajseerksa.com/ and bilingual raw files.

| Section | Decision | Evidence / reason | Required change |
|---|---|---|---|
| Company identity and 2009 history | KEEP + NEEDS BUSINESS CONFIRMATION | Specific company history; not independently verified | Preserve meaning; confirm date and legal/trading names |
| About paragraph | REFINE | Dense single paragraph; “company keep”; inconsistent Elearning | Break into positioning and history; standardize e-learning |
| Mission / vision | REFINE | Clear educational intention but awkward English | Preserve purpose; approve equivalent Arabic/English wording |
| Services intro | REFINE | “optimal solutions” is vague and “in the world” may overstate reach | State actual service categories, no implied global operations |
| Multimedia | EXPAND | Lists production formats, no examples/outcomes | Add approved sample and scope |
| E-learning | REFINE + NEEDS BUSINESS CONFIRMATION | “all computers” is absolute; “It is also meet”; broad SCORM and platform claims | Confirm versions, device matrix, meaning of adaptive content and support |
| STEM | EXPAND | Short English copy omits Arabic text-to-interactive-design detail | Align languages; confirm STEM vs STEAM terminology and workshop scope |
| AR/VR | EXPAND + NEEDS BUSINESS CONFIRMATION | Wide list includes holograms and games without demonstrations | Confirm current delivery capabilities and approved examples |
| Training/consulting | EXPAND | General experience claims, no consultant or method evidence | Request expertise areas, deliverables and approved biographies |
| Brand banners | MERGE | Repeated visual themes, not service evidence | Use themes sparingly within positioning; remove repetitive motion if approved |
| Contact | KEEP + NEEDS BUSINESS CONFIRMATION | Three phones, one unusually short; private@ email | Confirm public enquiry owner, full address, hours and preferred channel |
| Embedded video title | REFINE | Unrelated template wording | Use accurate accessible title; review content and rights |
| Version label | REMOVE (proposed) | v 1.0.1 is internal-looking menu text | Omit from redesigned public navigation |
| Footer year | NEEDS BUSINESS CONFIRMATION | © 2024 seen in 2026 | Confirm desired copyright wording |
| SEO description | REFINE | create-react-app placeholder | Write bilingual company-specific description |

## Arabic editorial issues
Preserve raw spelling. Proposed corrections include تطوير المقرات الإلكترونية → تطوير المقررات الإلكترونية; خدمتنا → خدماتنا; تفاعليه → تفاعلية; الحقائب تعليمية → الحقائب التعليمية; دروس مبينة → دروس مبنية. “ستيم” alongside STEM may confuse STEM with STEAM; business approval must determine the intended methodology. English adaptive-content wording and Arabic user-journey wording are not exact equivalents. Do not introduce adaptive-learning functionality beyond the approved scope.

## Missing proof and business information
No approved project summaries, named client permission, testimonials, statistics, awards, certifications, case-study outcomes, delivery stages, service limits, indicative timelines, team biographies, enquiry response expectations or privacy handling details were supplied. These are gaps, not evidence the company lacks them.

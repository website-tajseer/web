# Redesign direction — planning only

## Design Philosophy
Make an educational technology services company understandable and credible through clear text, visible capabilities and authentic learning examples. No UI has been designed or implemented.

## Brand Personality
Professional, educational, technologically capable and grounded in Saudi context. Treat innovation as intent unless proof supports stronger wording. Avoid generic SaaS dashboards, subscription pricing patterns and invented product interfaces.

## Color Strategy
Preserve the observed blue/teal family and approved logo. Use calm neutral reading surfaces, navy text and teal/blue accents as PROPOSED roles; final values require contrast testing. Limit gradients to purposeful brand areas. Reserve red for meaningful status/location use, not arbitrary primary CTAs.

## Typography Strategy
Cairo is the existing bilingual foundation and a sensible continuity option. Validate Arabic shaping, weight, loading and licensing. Proposed body size 16–18 CSS px with comfortable script-specific line height; avoid tiny descriptions and all-capital long headings.

## Layout Strategy
Clear sections with readable text and visible service summaries. Put important content in normal document flow. Avoid large empty gaps and narrow mission columns.

## Grid
PROPOSED: 12-column desktop, 4-column mobile; content max width around 1200px. Services can use three columns on wide screens, two where copy fits, one on narrow screens. Validate with real bilingual content rather than fixed card heights.

## Spacing
PROPOSED 4/8px-based spacing scale; 24–32px card padding where space permits, 48–96px section spacing depending on viewport. Typography and content density determine final choices.

## Cards
Real headings, concise body text and clear links; no hover flip or hidden essential text. Match image ratios while allowing text height to grow. Modest, consistent corner radius.

## Buttons
One obvious primary action per section; secondary text/outline actions. Provide visible hover, focus, pressed, disabled and loading states. Prefer explicit enquiry wording over ambiguous “Learn more”.

## Navigation
Home, About, Services, Contact, language switch. Service subnavigation must work with click, touch and keyboard. Mobile menu needs an accessible label, expanded state, managed focus, Escape close and focus return.

## Hero Style
Text headline and concise explanation first. Optional approved learning image or restrained existing video with poster and pause; never require video playback to understand the company.

## Imagery
Prioritize approved course screenshots, learning environments and project examples. Preserve source assets until quality/rights review. Replace text-baked service art with live text and restrained imagery where approved.

## Icons
Consistent stroke/weight system; decorative icons hidden from assistive technology, functional controls labelled. Mirror directional arrows when appropriate, not logos or media.

## Motion / Animation
Brief optional transitions. Respect reduced-motion preferences, avoid perpetual marquee and large entrance delays. Essential content remains visible if animation fails.

## Microinteractions
Clear navigation focus, link state and future form feedback. No implied booking or guaranteed response before operational workflows are defined.

## Mobile Experience
Single-column readable content, visible summaries, comfortable touch targets (proposed minimum 44px), no hover dependency or horizontal content loss. Validate 320, 390, 768 CSS px and real devices later.

## Desktop Experience
Balanced reading widths, predictable navigation, coherent service grid and proof content. Check 1024, 1440 and zoomed layouts with actual copy.

## Arabic / RTL Considerations
Set lang=ar and dir=rtl; logical CSS properties; review line breaks and punctuation with Arabic editors. Keep email/phone values directionally isolated so digits do not reorder. Approve STEM terminology and Arabic company name. Do not mirror the logo.

## English / LTR Considerations
Set lang=en and dir=ltr; use consistent “e-learning”, “AR and VR” and sentence case. Keep equivalent facts and navigation destinations between languages.

## Accessibility
Target WCAG 2.2 AA in future design/implementation; this is a target, not a certification. Semantic landmarks/headings, visible focus, keyboard access, contrast tests, zoom/reflow, useful alt, captions/transcripts for meaningful video, reduced motion, and explicit form labels/errors.

## Design Consistency Rules
Single token set, one source of approved bilingual content, shared component states, no rasterized essential text, no claims without source/status, and no empty proof sections. Freeze official brand tokens only after review. No frontend framework decision is necessary for this discovery deliverable.

# Website inventory

Inspected 14 September 2026. EXISTING FACTS means statements or behavior observed on the website; company claims are not independently verified. INFERRED means analyst interpretation. RECOMMENDED / PROPOSED CONTENT is not approved company copy.

One unique public content URL found, with two language states and several sections. Section labels below are not distinct pages.

| Page | URL | Navigation | Purpose | Main Content | CTA | Notes |
|---|---|---|---|---|---|---|
| Home | https://tajseerksa.com/ | Home / الرئيسية | Entry and identity | Video hero | None | Section id Home; no textual hero heading |
| About section | https://tajseerksa.com/ | About us / من نحن | Company explanation | Profile, mission, vision, video | None | Section id About |
| Services section | https://tajseerksa.com/ | Service / خدماتنا | Capability discovery | Five service descriptions | None | Section id Service; no detail links |
| Theme banner section | https://tajseerksa.com/ | Not in nav | Visual brand themes | Education, Technology, Thinking | None | Section id Consulting is misleading internally; not a sixth service |
| Contact/footer | https://tajseerksa.com/ | Footer and mobile-menu contacts | Enquiry | Address, three phones, email | Map / call / email | No form or dedicated route |
| Arabic state | https://tajseerksa.com/ | AR button, then EN | Arabic content | Translated content and images | Same footer actions | dir=rtl but lang=en; no separate locale URL |

## Discovery scope
All first-party anchor destinations in both language states and the mobile menu resolve to /. Home, About and Service are section-navigation controls, not separate URLs. Service cards contain no anchors. No PDFs, portfolio links, social links in the main document, client pages, news pages or download links were found. YouTube's embedded player exposes its video and channel externally.

robots.txt was blocked by the browser (ERR_BLOCKED_BY_CLIENT). Read-only web retrieval of robots.txt and sitemap.xml also failed with tool safety errors. These are retrieval limitations, not demonstrated server 404 responses. A site:tajseerksa.com search returned no results. No sitemap content was retrieved. Reachable rendered content is covered; undisclosed or unlinked server routes cannot be ruled out. See crawl-log.md.

# Content matrix

Source content is ready for reference. Draft copy is ready for review, not publication. Every page has matched English/Arabic drafts; technical claims and naming remain gated.

| Page | Section | Content Status | Source | Needs Rewrite | Needs Business Input | Visual Needed |
|---|---|---|---|---|---|---|
| Home | Hero | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Home | Services | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Home | Company | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Optional; see copy requirements |
| Home | Approach | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Home | Evidence | NEEDS BUSINESS CONFIRMATION | New evidence needed | Draft prepared | Yes | Approved work / scope asset |
| Home | Contact | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| About | Profile | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Optional; see copy requirements |
| About | Mission | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| About | Vision | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| About | Experience | NEEDS BUSINESS CONFIRMATION | New evidence needed | Draft prepared | Yes | Approved work / scope asset |
| Services | Overview | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Services | Five service summaries | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Services | Selection guidance | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Contact | Channels | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Optional; see copy requirements |
| Contact | Location | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Optional; see copy requirements |
| Contact | Project context | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Interactive Multimedia | Scope | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Interactive Multimedia | Application | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Interactive Multimedia | Technology | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Approved work / scope asset |
| Interactive Multimedia | Example | NEEDS BUSINESS CONFIRMATION | New evidence needed | Draft prepared | Yes | Approved work / scope asset |
| Interactive Multimedia | Enquiry | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| E-learning Course Development | Scope | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| E-learning Course Development | Application | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| E-learning Course Development | Technology | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Approved work / scope asset |
| E-learning Course Development | Example | NEEDS BUSINESS CONFIRMATION | New evidence needed | Draft prepared | Yes | Approved work / scope asset |
| E-learning Course Development | Enquiry | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| STEM Methodology | Scope | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| STEM Methodology | Application | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| STEM Methodology | Technology | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Approved work / scope asset |
| STEM Methodology | Example | NEEDS BUSINESS CONFIRMATION | New evidence needed | Draft prepared | Yes | Approved work / scope asset |
| STEM Methodology | Enquiry | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| AR and VR Environments | Scope | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| AR and VR Environments | Application | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| AR and VR Environments | Technology | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Approved work / scope asset |
| AR and VR Environments | Example | NEEDS BUSINESS CONFIRMATION | New evidence needed | Draft prepared | Yes | Approved work / scope asset |
| AR and VR Environments | Enquiry | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Training and Consulting | Scope | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Training and Consulting | Application | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |
| Training and Consulting | Technology | NEEDS BUSINESS CONFIRMATION | /, bilingual raw archive and service analysis | Draft prepared | Yes | Approved work / scope asset |
| Training and Consulting | Example | NEEDS BUSINESS CONFIRMATION | New evidence needed | Draft prepared | Yes | Approved work / scope asset |
| Training and Consulting | Enquiry | PROPOSED draft; approval pending | /, bilingual raw archive and service analysis | Draft prepared | Editorial approval | Optional; see copy requirements |

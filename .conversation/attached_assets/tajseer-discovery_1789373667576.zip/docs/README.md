# Tajseer discovery and redesign preparation

Audit date: 14 September 2026. Source: https://tajseerksa.com/.

Start with [redesign-readiness-report.md](redesign-readiness-report.md), then [business-analysis.md](business-analysis.md), [website-inventory.md](website-inventory.md) and [proposed-sitemap.md](proposed-sitemap.md).

## What is included
- One observed public content URL, two language states, five services.
- 19 raw content Markdown files: nine per language plus media wording.
- 18 proposed copy Markdown files: nine per language (Home, About, Services, Contact and five service detail pages).
- Five service-analysis dossiers with all 13 requested fields.
- Brand, asset, UX, content, architecture, homepage, component and readiness documentation.
- Original exported media, bilingual rendered DOM/text evidence, screenshots, asset contact sheet and checksums.

## Reading rules
EXISTING FACTS are observed website statements/behavior, not independent validation of company claims. INFERRED is analyst interpretation. RECOMMENDED / PROPOSED CONTENT is draft material requiring approval. [BUSINESS INPUT REQUIRED] marks information that must be supplied or confirmed; omit conditional sections if unavailable.

The site is a single-page experience. Section archive files do not imply separate existing pages. Future detail pages are proposals. No frontend UI or implementation has been created.

## Important limitations
robots.txt and sitemap.xml could not be retrieved through the available tools. The complete observed internal anchor graph was inspected, but unlinked historical pages cannot be excluded. Full embedded YouTube content was not transcribed. Mobile inspection covers the initial narrow layout; the attempted 390px override failed and is not counted. Read [crawl-log.md](crawl-log.md) and [final-validation.md](final-validation.md).

## Handoff sequence
Review source archive → confirm business facts and technical scope → approve bilingual copy and assets → explicitly authorize design. Implementation requires a later instruction.

## File index
- [assets-inventory.md](assets-inventory.md)
- [brand-analysis.md](brand-analysis.md)
- [business-analysis.md](business-analysis.md)
- [component-inventory.md](component-inventory.md)
- [content/raw/about.md](content/raw/about.md)
- [content/raw/ar/about.md](content/raw/ar/about.md)
- [content/raw/ar/contact.md](content/raw/ar/contact.md)
- [content/raw/ar/home.md](content/raw/ar/home.md)
- [content/raw/ar/services/ar-vr.md](content/raw/ar/services/ar-vr.md)
- [content/raw/ar/services/elearning-development.md](content/raw/ar/services/elearning-development.md)
- [content/raw/ar/services/interactive-multimedia.md](content/raw/ar/services/interactive-multimedia.md)
- [content/raw/ar/services/stem.md](content/raw/ar/services/stem.md)
- [content/raw/ar/services/training-consulting.md](content/raw/ar/services/training-consulting.md)
- [content/raw/ar/services.md](content/raw/ar/services.md)
- [content/raw/contact.md](content/raw/contact.md)
- [content/raw/home.md](content/raw/home.md)
- [content/raw/media.md](content/raw/media.md)
- [content/raw/services/ar-vr.md](content/raw/services/ar-vr.md)
- [content/raw/services/elearning-development.md](content/raw/services/elearning-development.md)
- [content/raw/services/interactive-multimedia.md](content/raw/services/interactive-multimedia.md)
- [content/raw/services/stem.md](content/raw/services/stem.md)
- [content/raw/services/training-consulting.md](content/raw/services/training-consulting.md)
- [content/raw/services.md](content/raw/services.md)
- [content/redesign/about.md](content/redesign/about.md)
- [content/redesign/ar/about.md](content/redesign/ar/about.md)
- [content/redesign/ar/contact.md](content/redesign/ar/contact.md)
- [content/redesign/ar/home.md](content/redesign/ar/home.md)
- [content/redesign/ar/services/ar-vr.md](content/redesign/ar/services/ar-vr.md)
- [content/redesign/ar/services/elearning-development.md](content/redesign/ar/services/elearning-development.md)
- [content/redesign/ar/services/interactive-multimedia.md](content/redesign/ar/services/interactive-multimedia.md)
- [content/redesign/ar/services/stem.md](content/redesign/ar/services/stem.md)
- [content/redesign/ar/services/training-consulting.md](content/redesign/ar/services/training-consulting.md)
- [content/redesign/ar/services.md](content/redesign/ar/services.md)
- [content/redesign/contact.md](content/redesign/contact.md)
- [content/redesign/home.md](content/redesign/home.md)
- [content/redesign/services/ar-vr.md](content/redesign/services/ar-vr.md)
- [content/redesign/services/elearning-development.md](content/redesign/services/elearning-development.md)
- [content/redesign/services/interactive-multimedia.md](content/redesign/services/interactive-multimedia.md)
- [content/redesign/services/stem.md](content/redesign/services/stem.md)
- [content/redesign/services/training-consulting.md](content/redesign/services/training-consulting.md)
- [content/redesign/services.md](content/redesign/services.md)
- [content-audit.md](content-audit.md)
- [content-matrix.md](content-matrix.md)
- [crawl-log.md](crawl-log.md)
- [current-sitemap.md](current-sitemap.md)
- [final-validation.md](final-validation.md)
- [homepage-strategy.md](homepage-strategy.md)
- [proposed-sitemap.md](proposed-sitemap.md)
- [redesign-direction.md](redesign-direction.md)
- [redesign-readiness-report.md](redesign-readiness-report.md)
- [services-analysis/ar-vr.md](services-analysis/ar-vr.md)
- [services-analysis/elearning-development.md](services-analysis/elearning-development.md)
- [services-analysis/interactive-multimedia.md](services-analysis/interactive-multimedia.md)
- [services-analysis/stem.md](services-analysis/stem.md)
- [services-analysis/training-consulting.md](services-analysis/training-consulting.md)
- [ux-audit.md](ux-audit.md)
- [website-inventory.md](website-inventory.md)

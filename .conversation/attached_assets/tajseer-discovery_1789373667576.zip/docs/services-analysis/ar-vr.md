# AR and VR Environments

## 1. Service name — EXISTING FACTS
AR AND VR ENVIRONMENTS / بيئات الواقع المعزز AR والافتراضي VR

## 2. Existing description
Tajseer keeps pace with the rapid developments in real and virtual education and training technologies, as it provides services for designing and developing virtual laboratories for technical and vocational education and training using (360 image, augmented reality-AR, virtual reality-VR) technologies. We also developing 2D/3D educational games and employing VR technologies and holograms in composing lessons based on the STEM methodology

Arabic original: content/raw/ar/services/ar-vr.md. Both are from https://tajseerksa.com/, Services section.

## 3. Main customer problem — INFERRED
Technical and vocational learning may need simulated or immersive environments.

## 4. Tajseer's solution — EXISTING WEBSITE CLAIM
Virtual laboratories, 360 imagery, AR/VR, 2D/3D educational games and VR/hologram use in STEM lessons.

## 5. Potential target customer
Technical/vocational education and training is explicit; specific purchasing roles are INFERRED.

## 6. Technologies / methodologies mentioned
360 image; AR; VR; 2D/3D; holograms; STEM.

## 7. Business value
Provide immersive ways to explore learning content — INFERRED; no safety or effectiveness claims verified.

## 8. Supporting content available
One English and one Arabic paragraph, a title image in each language. No linked detail page, attributable case study or service-specific proof found. General company video is not service-specific evidence.

## 9. Existing visuals / assets
English: https://tajseerksa.com/static/media/Services-10.a9bfe45eb1636e625dcc.png

Arabic: https://tajseerksa.com/static/media/Services-09.32a11e8b34de414b315d.png

## 10. Existing CTA
None for this service. Global footer phone/email/map only.

## 11. Missing information
[BUSINESS INPUT REQUIRED: Current hardware/software scope, deployment modes, accessibility alternatives, demonstrations, maintenance and hologram capability.]

## 12. Content weaknesses
Many technologies are grouped together without use cases or evidence.

## 13. Recommended content improvements
RECOMMENDED / PROPOSED CONTENT: start with the learner/organization need, show the verified outputs, explain scope in plain language, include an approved demonstration and a contextual enquiry CTA. Proposed headline: “Explore immersive environments for education and training”. Retain detailed technical claims only after the requested confirmation. Do not imply improved grades, engagement rates or cost savings without evidence.

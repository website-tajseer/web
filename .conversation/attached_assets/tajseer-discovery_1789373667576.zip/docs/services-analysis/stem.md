# STEM Methodology

## 1. Service name — EXISTING FACTS
STEM METHODOLOGY / منهجية ستيم STEM

## 2. Existing description
Tajseer provides services for creating courses and educational packages based on the STEM methodology, implementing specialized training workshops (STEM Workshops) and educational/instructional design models.

Arabic original: content/raw/ar/services/stem.md. Both are from https://tajseerksa.com/, Services section.

## 3. Main customer problem — INFERRED
Educators need structured STEM learning content and practical development support.

## 4. Tajseer's solution — EXISTING WEBSITE CLAIM
STEM-based courses and educational packages, specialist workshops, instructional-design models; Arabic adds converting text to interactive digital models.

## 5. Potential target customer
Educational institutions and educators — INFERRED buyer roles.

## 6. Technologies / methodologies mentioned
STEM methodology; STEM Workshops; instructional design.

## 7. Business value
Structure STEM content and support educators through workshops — INFERRED.

## 8. Supporting content available
One English and one Arabic paragraph, a title image in each language. No linked detail page, attributable case study or service-specific proof found. General company video is not service-specific evidence.

## 9. Existing visuals / assets
English: https://tajseerksa.com/static/media/Services-08.57f204cc785d1f15406d.png

Arabic: https://tajseerksa.com/static/media/Services-07.9908798641ec4bad555b.png

## 10. Existing CTA
None for this service. Global footer phone/email/map only.

## 11. Missing information
[BUSINESS INPUT REQUIRED: STEM vs STEAM, learner age ranges, workshop format, subjects, curriculum alignment and examples.]

## 12. Content weaknesses
English omits Arabic detail; minimal explanation of practical outputs.

## 13. Recommended content improvements
RECOMMENDED / PROPOSED CONTENT: start with the learner/organization need, show the verified outputs, explain scope in plain language, include an approved demonstration and a contextual enquiry CTA. Proposed headline: “Bring STEM methodology into learning content”. Retain detailed technical claims only after the requested confirmation. Do not imply improved grades, engagement rates or cost savings without evidence.

# Contact

RECOMMENDED / PROPOSED CONTENT — working copy, not approved for publication. Source baseline: https://tajseerksa.com/ and corresponding raw files. Bracketed business inputs must be resolved or the section omitted before publication.

## Purpose
Get in touch

## Primary Audience
Organizations ready to discuss educational content or training needs.

## Hero
### Headline
Discuss your next learning project
### Supporting Text
Contact Tajseer to discuss your educational content, learning technology or training requirements.
### Primary CTA
Email Tajseer
### Secondary CTA
Call Tajseer

## Sections

### Channels

**Heading:** Get in touch

**Supporting copy:** Email: private@tajseerksa.com. Telephone details are preserved in the raw contact archive.

**Suggested CTA:** Email / Call

**Content/visual requirements:** [BUSINESS INPUT REQUIRED: Confirm preferred public mailbox and all phone numbers before use.]

### Location

**Heading:** Find Tajseer in Riyadh

**Supporting copy:** Riyadh – Olaya Street.

**Suggested CTA:** Open map

**Content/visual requirements:** Use captured map URL only after business confirms location. No invented building, hours or postal address.

### Project context

**Heading:** Help us understand your needs

**Supporting copy:** When contacting us, describe your organization, learners, content area and intended delivery environment.

**Suggested CTA:** Send your enquiry

**Content/visual requirements:** Optional future form requires approved fields, destination, consent/privacy text and error/success states; no form implementation now.

## SEO preparation

Proposed title: Contact | Tajseer

Proposed description: Contact Tajseer to discuss your educational content, learning technology or training requirements.

Use locale-specific URLs and reciprocal language links. Confirm official English/Arabic brand names before publishing. Do not add claims or keyword lists beyond verified scope.

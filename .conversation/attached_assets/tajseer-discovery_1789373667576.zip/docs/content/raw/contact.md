# Contact/footer — en

## Source URL
https://tajseerksa.com/

## Existing Title
Browser title: Tajseer. Section title: Find us / موقعنا

## Existing Content
Find us

Riyadh - Olaya Street

Call us

00966-114-621-717

00966-545-992-326

00966-11-247-121

Email

private@tajseerksa.com

© 2024 Tajseer, All Rights Reserved.

## Existing CTA
No dedicated section CTA. Global footer provides map, telephone and email links. Navigation offers Home / About us / Service and an AR/EN switch.

## Existing Images / Media
Inline location, telephone, envelope SVG icons.

## Existing Links
- [Riyadh - Olaya Street](https://www.google.com/maps/place/%D8%AA%D8%AC%D8%B3%D9%8A%D8%B1+%D8%A7%D9%84%D9%81%D9%83%D8%B1+%D9%84%D9%84%D8%A3%D8%B3%D8%AA%D8%B4%D8%A7%D8%B1%D8%A7%D8%AA+%D8%A7%D9%84%D8%AA%D8%B1%D8%A8%D9%88%D9%8A%D8%A9+%D9%88%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%D9%8A%D8%A9%D8%8C+%D8%A7%D9%84%D8%B9%D9%84%D9%8A%D8%A7%D8%8C+%D8%A7%D9%84%D8%B9%D9%84%D9%8A%D8%A7%D8%8C+Al+Olaya,+Riyadh+12222,+Saudi+Arabia%E2%80%AD/@24.694603,46.685274,16z/data=!4m2!3m1!1s0x3e2f033eb433d1d3:0xece85b9a20e77994?hl=en&gl=JO)
- [00966-114-621-717](tel:00966114621717)
- [00966-545-992-326](tel:00966545992326)
- [00966-11-247-121](tel:0096611247121)
- [private@tajseerksa.com](mailto:private@tajseerksa.com)

## Existing Contact Information
- [Riyadh - Olaya Street](https://www.google.com/maps/place/%D8%AA%D8%AC%D8%B3%D9%8A%D8%B1+%D8%A7%D9%84%D9%81%D9%83%D8%B1+%D9%84%D9%84%D8%A3%D8%B3%D8%AA%D8%B4%D8%A7%D8%B1%D8%A7%D8%AA+%D8%A7%D9%84%D8%AA%D8%B1%D8%A8%D9%88%D9%8A%D8%A9+%D9%88%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%D9%8A%D8%A9%D8%8C+%D8%A7%D9%84%D8%B9%D9%84%D9%8A%D8%A7%D8%8C+%D8%A7%D9%84%D8%B9%D9%84%D9%8A%D8%A7%D8%8C+Al+Olaya,+Riyadh+12222,+Saudi+Arabia%E2%80%AD/@24.694603,46.685274,16z/data=!4m2!3m1!1s0x3e2f033eb433d1d3:0xece85b9a20e77994?hl=en&gl=JO)
- [00966-114-621-717](tel:00966114621717)
- [00966-545-992-326](tel:00966545992326)
- [00966-11-247-121](tel:0096611247121)
- [private@tajseerksa.com](mailto:private@tajseerksa.com)

## Notes
Verbatim rendered DOM wording, including existing errors. This is a section archive, not evidence of a separate URL. No standalone Contact page or contact form found. Third telephone is unusually short; preserve literally until confirmed.

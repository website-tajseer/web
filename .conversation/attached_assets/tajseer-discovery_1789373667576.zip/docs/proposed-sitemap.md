# Proposed information architecture

RECOMMENDED. Launch scope: nine pages per language, subject to approved service-detail content. Arabic and English are equivalent trees, e.g. /ar/ and /en/. Confirm root-language behavior before implementation. Current site has only /; new section-derived routes are PROPOSED NEW PAGE, not existing standalone pages.

```text
Home
├── About
├── Services
│   ├── Interactive Multimedia
│   ├── E-learning Course Development
│   ├── STEM Methodology
│   ├── AR and VR Environments
│   └── Training and Consulting
└── Contact
```

| Page | Status | Why / audience | Conversion goal | Main sections |
|---|---|---|---|---|
| Home | EXISTING PAGE, restructured | First-time institutional visitors need immediate orientation | Service exploration / enquiry | Positioning, services, company, approach, conditional evidence, contact |
| About | PROPOSED NEW PAGE from existing section | Buyers evaluating credibility | Qualified contact | Profile, mission, vision, approved expertise |
| Services | PROPOSED NEW PAGE from existing section | Buyers selecting capability | Relevant detail page | Five summaries, selection guidance, enquiry |
| Interactive Multimedia | PROPOSED NEW PAGE | Learning content teams | Contextual enquiry | Scope, applications, formats, approved example |
| E-learning Course Development | PROPOSED NEW PAGE | Digital learning teams | Platform/content enquiry | Scope, publishing compatibility, approved sample |
| STEM Methodology | PROPOSED NEW PAGE | Educators and institutions | Course/workshop enquiry | Packages, workshops, methodology scope |
| AR and VR Environments | PROPOSED NEW PAGE | Technical/vocational learning providers | Immersive-project enquiry | Labs, methods, device requirements, sample |
| Training and Consulting | PROPOSED NEW PAGE | Learning/training decision-makers | Consultancy enquiry | Scope, expertise, engagement details |
| Contact | PROPOSED NEW PAGE from existing footer | Ready-to-contact visitors | Email/call, optional form | Channels, location, enquiry guidance |

Do not launch empty service detail pages; if scope remains insufficient, keep the approved detail in the Services page until ready. Do not duplicate Services with a generic Solutions page. Projects may be a later PROPOSED NEW PAGE only after approved cases exist; use a conditional homepage proof block first. Clients and Insights need permissions and an editorial owner respectively, so neither belongs in the initial sitemap. Privacy information should be added if the approved enquiry/analytics setup requires it; wording and processing facts need review rather than fabricated policy text. Plan redirects only for real legacy URLs discovered from an owner-provided inventory.

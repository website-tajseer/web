# Crawl and evidence log

Date: 14 September 2026. Main method: user-requested Codex in-app Browser, read-only DOM inspection, screenshots, visible navigation and observed-asset export.

| Check | Result | Limit |
|---|---|---|
| https://tajseerksa.com/ | Rendered; English captured | Company statements not independently verified |
| AR toggle | Arabic text/assets and RTL captured, same URL | lang stays en |
| Home/About/Service anchors | All href=/; service navigation exercised in mobile and desktop | No independent detail pages linked |
| Mobile overlay | Three nav links, map/email, version | No enquiry transmitted |
| Service cards | Five full DOM descriptions and paired imagery | Hover CSS; no keyboard-focusable card |
| Footer | Map, three tel links, mailto captured | Destination ownership/deliverability not tested |
| YouTube embed | Player title/channel observed | Full audiovisual content not transcribed |
| robots.txt | Browser blocked; web tool also failed | Not a proven site-side error |
| sitemap.xml | Web tool safe-open failure | Contents unknown, not a proven 404 |
| Search site:tajseerksa.com | No results | Search index not exhaustive |
| Asset bundle | 27 exported items, zero reported failures | Font binaries not observed; separate Arabic data-URI logo saved |
| Desktop | 1440×1000 | Functional smoke inspection, not full QA |
| Narrow layout | Initial screenshots 496×809 | Physical mobile device not tested |
| Requested 390×844 | Did not take effect; DOM reported 1440×1000 | Explicitly excluded from mobile coverage |

No authenticated/private pages accessed. No contact form submitted, calls made, messages sent, external state changed or frontend code written. Temporary viewport override reset. No additional same-origin content routes appeared in the inspected anchor graph. Owner-provided CMS/export/Search Console inventories are needed to exclude unlinked historical pages conclusively.

Evidence JSON retains rendered HTML, exact text, images and links in both locales. This is a rendered-state archive, not the original HTTP response or a full deployable site backup. Snapshot timestamps and random image alt values can differ between captures. Original asset filenames are preserved.

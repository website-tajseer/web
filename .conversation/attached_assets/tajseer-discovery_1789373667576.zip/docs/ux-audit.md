# UX audit

Inspected 14 September 2026. EXISTING FACTS means statements or behavior observed on the website; company claims are not independently verified. INFERRED means analyst interpretation. RECOMMENDED / PROPOSED CONTENT is not approved company copy.

Desktop checked at 1440×1000; initial narrow layout at 496×809. A requested 390×844 override did not take effect (DOM remained 1440×1000); do not count it as tested. No physical-device, full keyboard journey, screen-reader, Lighthouse, network-throttling or formal WCAG conformance test was performed. Severity reflects impact, not measured incidence. No CRITICAL issue established.

## UX-01 — HIGH: Service information depends on hover

**Problem:** Service information depends on hover.

**Impact:** Visitors using keyboard cannot reach the descriptive panel; touch discovery is uncertain.

**Evidence:** Archived CSS rotates .cardab__content -100deg and reveals it only on .cardab:hover. Cards are divs with no tabindex.

**Recommendation:** Keep summaries visible and provide semantic detail links. Avoid hover-only information and nested scroll areas.

## UX-02 — HIGH: No accessible heading hierarchy

**Problem:** No accessible heading hierarchy.

**Impact:** Assistive-technology users cannot scan the page effectively.

**Evidence:** DOM has no h1 or h2; one empty h3 wraps the logo. Section and service titles are p elements.

**Recommendation:** One descriptive h1, h2 sections, h3 card titles; add landmarks and a skip link.

## UX-03 — HIGH: Arabic document language remains English

**Problem:** Arabic document language remains English.

**Impact:** Screen readers may pronounce Arabic incorrectly; locale indexing is ambiguous.

**Evidence:** Arabic DOM: dir=rtl, lang=en. Same URL and no hreflang links.

**Recommendation:** Set lang=ar with RTL and use stable locale URLs with matching canonical/hreflang.

## UX-04 — HIGH: Hero does not explain the business in text

**Problem:** Hero does not explain the business in text.

**Impact:** First-time visitors must scroll to understand the offer.

**Evidence:** Home section has a video and overlay, no rendered heading, supporting text or CTA.

**Recommendation:** Add institutional positioning, concise service scope and a primary enquiry CTA.

## UX-05 — HIGH: Placeholder search metadata

**Problem:** Placeholder search metadata.

**Impact:** Search snippets cannot clearly communicate company relevance.

**Evidence:** description is Web site created using create-react-app; title is Tajseer; no canonical/hreflang observed.

**Recommendation:** Provide unique bilingual title/description and validate rendered metadata and indexability.

## UX-06 — MEDIUM: Service enquiry path is indirect

**Problem:** Service enquiry path is indirect.

**Impact:** Buyers must find contact details after exploring services.

**Evidence:** No service CTA, detail link or form; phone/email appear in footer.

**Recommendation:** Add contextual enquiry links and a clearly labelled Contact destination.

## UX-07 — MEDIUM: Non-descriptive image and control names

**Problem:** Non-descriptive image and control names.

**Impact:** Brand and navigation are unclear to assistive technology.

**Evidence:** Logo alt=a; service images alt empty despite embedded text; banner alts are random decimals; menu button unnamed; moon icon sits in a div.

**Recommendation:** Name controls, expose state, use text headings outside imagery, use meaningful or decorative alt as appropriate.

## UX-08 — MEDIUM: Continuous motion with no visible pause

**Problem:** Continuous motion with no visible pause.

**Impact:** Motion can distract users and complicate reading.

**Evidence:** Hero autoplay loop has controls=false; banner repeats; background SVG animated; no prefers-reduced-motion rule found in archived main CSS.

**Recommendation:** Provide pause and reduced-motion alternatives; use a static hero fallback.

## UX-09 — MEDIUM: Dense copy and hidden card scrolling

**Problem:** Dense copy and hidden card scrolling.

**Impact:** Long paragraphs are hard to scan, especially on narrow screens.

**Evidence:** Small mission/vision body text in 496px screenshot; cards have overflow-y:auto and hidden scrollbars.

**Recommendation:** Use concise visible summaries, normal document flow and readable line lengths.

## UX-10 — MEDIUM: Weak proof of capability

**Problem:** Weak proof of capability.

**Impact:** Institutional buyers cannot evaluate experience from evidence.

**Evidence:** No named clients, case studies, measurable results, certifications or testimonials in rendered copy.

**Recommendation:** Request approved examples and evidence; show no invented logos or metrics.

## UX-11 — MEDIUM: Logo and banners lose contrast against blue

**Problem:** Logo and banners lose contrast against blue.

**Impact:** Brand recognition and theme labels become less legible.

**Evidence:** Desktop/footer screenshots show low-contrast cyan logo and subdued banner labels on blue. Contrast ratios not measured.

**Recommendation:** Use approved contrasting logo variants and test every final color pairing.

## UX-12 — LOW: Template and stale interface wording

**Problem:** Template and stale interface wording.

**Impact:** Presentation feels unfinished.

**Evidence:** iframe title Social Media Marketing | Content Creation Tool; footer 2024; menu v 1.0.1.

**Recommendation:** Give video an accurate title, confirm copyright policy, remove implementation version from public menu.

## Navigation, layout and responsiveness
Mobile menu opened and its Service link closed the overlay and scrolled to Services. Desktop service navigation also scrolled successfully. Telephone/email destinations were inspected, not activated; no test enquiry was sent. The map URL was captured without independently verifying the location listing. Footer stacks in the narrow screenshot and uses three columns on desktop. Arabic mirrors layout and uses alternate images. Large gaps and narrow mission/vision columns weaken desktop balance. No confirmed broken first-party page link was found.

## Performance perception
The hero is video-based, YouTube is embedded, and several sections animate into view. Some captures showed a black or loading video area, but this is not proof of persistent playback failure. Resource weights are listed in assets-inventory.md. Do not describe performance as measured fast or slow; test loading, layout shift and interaction performance before implementation approval.

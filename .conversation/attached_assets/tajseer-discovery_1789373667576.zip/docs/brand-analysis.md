# Brand and visual identity analysis

EXISTING FACTS from rendered styles, archived assets and screenshots; not an official brand guide.

## Logo
Header uses TajsserLogo…svg in English. Arabic state uses an embedded PNG (204×72), archived as arabic-logo.png. English SVG intrinsic dimensions reported 1739×643. Both visually show an angular TAJSEER wordmark with Arabic lettering and a circular T-like symbol/triangular pointer. English placement is left; Arabic placement is right. No approved monochrome/print lockup or brand manual was discovered. Preserve original artwork; confirm whether the Arabic-state raster is an approved variation.

## Colors
| Observed value | Role / evidence |
|---|---|
| #008DA9 | Teal component of page gradient; opacity varies by breakpoint |
| #005CA8 | Blue component of page gradient |
| #00052D | Dark navy desktop gradient component (alpha .877) |
| #00395D | Hero overlay gradient endpoint |
| #00407E | Animated background SVG fill |
| #FFFFFF | Main type and icons |
| #94A3B8 | Muted footer text |
| #EF4444 | Location-pin accent |

Values are CSS observations, not validated official brand tokens; composited on-screen colors differ because of transparency. Logo cyan/blue colors remain in the archived vector. Avoid choosing a new dominant hue before brand review.

## Typography
Cairo, sans-serif is the computed family. Google Fonts stylesheet requests weights 200–1000, display=swap. Both scripts use this family. Headings are visually large, often bold; descriptive text shifts from small mobile sizes to larger desktop sizes. Exact delivered font binaries were not present in the asset discovery list (font count 0); stylesheet is archived. Validate font licensing and served subsets before future self-hosting.

## Visual language
Blue/teal gradients; rounded image cards; luminous network lines, globes, circuits, hexagons and waveform loops; technology-device banner illustrations; robot-hand video hero; a large animated organic SVG shape. Card labels are embedded in raster images and descriptions use rotating glass-like overlays. Footer icons mix a red pin with white telephone/envelope symbols. No authenticated customer/project photography was established.

## Brand personality — INFERRED
Educational: course development, institutions, mission and education banners. Technological: network/circuit imagery, AR/VR and video interfaces. Saudi: 2009 Saudi origin claim and Riyadh contact. Professional/institutional intent: consultancy and standards language. Innovation is communicated visually; it is not proven market leadership.

## Elements that MUST be preserved in the brief
Tajseer / تجسير الفكر identity pending naming approval; original bilingual logo artwork and distinctive symbol; recognizable blue/teal family; educational technology positioning; Saudi context; five service categories; mission/vision meaning; accessible bilingual experience. Preserve these as constraints without freezing current layout.

## Elements that can be modernized
Full-page gradients, low-contrast logo placement, text baked into service PNGs, excessive rounded corners, hover flips, perpetual banners, large empty gaps, nonsemantic headings, generic hero video treatment and uneven copy. Use real approved learning examples to make the identity tangible.

## Logo vector palette — technical extraction

The archived SVG contains #0AACE4, #2981C4, #2A82C3, #3176BA, #37B5B0 and #3ABAAE. These are actual artwork values, not proposed replacements. The favicon shows the symbol on its own.

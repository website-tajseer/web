# Asset inventory

Source: https://tajseerksa.com/. Assets are archived without changing or replacing the site. Actions refer only to future proposals.

| Asset | Source | Where used | Purpose | Quality | Recommended action |
|---|---|---|---|---|---|
| [css2](assets/css2) | https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap | Site styling | Reference only | Archived; not a future implementation dependency; 1,753 bytes | REVIEW |
| [main.07f14f89.css](assets/main.07f14f89.css) | https://tajseerksa.com/static/css/main.07f14f89.css | Site styling | Reference only | Archived; not a future implementation dependency; 17,300 bytes | REVIEW |
| [TajsserLogo.bc8c31e3b431f4abdefcf79540d093dc.svg](assets/TajsserLogo.bc8c31e3b431f4abdefcf79540d093dc.svg) | https://tajseerksa.com/static/media/TajsserLogo.bc8c31e3b431f4abdefcf79540d093dc.svg | Header / browser identity | Brand | SVG scalable; 16,259 bytes | KEEP |
| [banner-02.816a9ca03437f5f65286.png](assets/banner-02.816a9ca03437f5f65286.png) | https://tajseerksa.com/static/media/banner-02.816a9ca03437f5f65286.png | Theme strip | Education/technology/thinking | 1598×527; repeated/animated on site; 101,453 bytes | OPTIMIZE |
| [banner-03.2b8967a78c138c168449.png](assets/banner-03.2b8967a78c138c168449.png) | https://tajseerksa.com/static/media/banner-03.2b8967a78c138c168449.png | Theme strip | Education/technology/thinking | 1598×527; repeated/animated on site; 176,643 bytes | OPTIMIZE |
| [banner-01.1868b660fcadcfdfb8e7.png](assets/banner-01.1868b660fcadcfdfb8e7.png) | https://tajseerksa.com/static/media/banner-01.1868b660fcadcfdfb8e7.png | Theme strip | Education/technology/thinking | 1598×527; repeated/animated on site; 163,981 bytes | OPTIMIZE |
| [Tajseer.7b0865b6c44b2d3c6511.mp4](assets/Tajseer.7b0865b6c44b2d3c6511.mp4) | https://tajseerksa.com/static/media/Tajseer.7b0865b6c44b2d3c6511.mp4 | Home hero | Technology atmosphere | Review duration, rights, poster, captions if meaningful, and weight; 14,194,616 bytes | REVIEW |
| [favicon.png](assets/favicon.png) | https://tajseerksa.com/favicon.png | Header / browser identity | Brand | Raster; verify sizes; 1,181 bytes | KEEP |
| [Services-04.e08bed473928f5b89731.png](assets/Services-04.e08bed473928f5b89731.png) | https://tajseerksa.com/static/media/Services-04.e08bed473928f5b89731.png | Services, English | Service title artwork | Raster text; current artwork retained, propose live text in future; 52,568 bytes | REPLACE |
| [Services-02.750178934cb26bcee01c.png](assets/Services-02.750178934cb26bcee01c.png) | https://tajseerksa.com/static/media/Services-02.750178934cb26bcee01c.png | Services, English | Service title artwork | Raster text; current artwork retained, propose live text in future; 111,908 bytes | REPLACE |
| [Services-08.57f204cc785d1f15406d.png](assets/Services-08.57f204cc785d1f15406d.png) | https://tajseerksa.com/static/media/Services-08.57f204cc785d1f15406d.png | Services, English | Service title artwork | Raster text; current artwork retained, propose live text in future; 31,769 bytes | REPLACE |
| [Services-06.3e4de635be060c1849df.png](assets/Services-06.3e4de635be060c1849df.png) | https://tajseerksa.com/static/media/Services-06.3e4de635be060c1849df.png | Services, English | Service title artwork | Raster text; current artwork retained, propose live text in future; 117,733 bytes | REPLACE |
| [Services-10.a9bfe45eb1636e625dcc.png](assets/Services-10.a9bfe45eb1636e625dcc.png) | https://tajseerksa.com/static/media/Services-10.a9bfe45eb1636e625dcc.png | Services, English | Service title artwork | Raster text; current artwork retained, propose live text in future; 52,584 bytes | REPLACE |
| [Services-07.9908798641ec4bad555b.png](assets/Services-07.9908798641ec4bad555b.png) | https://tajseerksa.com/static/media/Services-07.9908798641ec4bad555b.png | Services, Arabic | Service title artwork | Raster text; current artwork retained, propose live text in future; 30,925 bytes | REPLACE |
| [banner-04.a4591f58aa8813293c02.png](assets/banner-04.a4591f58aa8813293c02.png) | https://tajseerksa.com/static/media/banner-04.a4591f58aa8813293c02.png | Theme strip | Education/technology/thinking | 1598×527; repeated/animated on site; 164,280 bytes | OPTIMIZE |
| [Services-03.ff0a57601fc7f1414455.png](assets/Services-03.ff0a57601fc7f1414455.png) | https://tajseerksa.com/static/media/Services-03.ff0a57601fc7f1414455.png | Services, Arabic | Service title artwork | Raster text; current artwork retained, propose live text in future; 53,033 bytes | REPLACE |
| [Services-09.32a11e8b34de414b315d.png](assets/Services-09.32a11e8b34de414b315d.png) | https://tajseerksa.com/static/media/Services-09.32a11e8b34de414b315d.png | Services, Arabic | Service title artwork | Raster text; current artwork retained, propose live text in future; 53,835 bytes | REPLACE |
| [Services-05.a2809515800bfded3d74.png](assets/Services-05.a2809515800bfded3d74.png) | https://tajseerksa.com/static/media/Services-05.a2809515800bfded3d74.png | Services, Arabic | Service title artwork | Raster text; current artwork retained, propose live text in future; 118,117 bytes | REPLACE |
| [banner-06.832cec95e9dc0369c6d6.png](assets/banner-06.832cec95e9dc0369c6d6.png) | https://tajseerksa.com/static/media/banner-06.832cec95e9dc0369c6d6.png | Theme strip | Education/technology/thinking | 1598×527; repeated/animated on site; 176,630 bytes | OPTIMIZE |
| [banner-05.4b145d0ddf5bad95b634.png](assets/banner-05.4b145d0ddf5bad95b634.png) | https://tajseerksa.com/static/media/banner-05.4b145d0ddf5bad95b634.png | Theme strip | Education/technology/thinking | 1598×527; repeated/animated on site; 99,418 bytes | OPTIMIZE |
| [Services-01.490db8566ce7063dffa3.png](assets/Services-01.490db8566ce7063dffa3.png) | https://tajseerksa.com/static/media/Services-01.490db8566ce7063dffa3.png | Services, Arabic | Service title artwork | Raster text; current artwork retained, propose live text in future; 110,446 bytes | REPLACE |
| [svg-1.svg](assets/svg-1.svg) | Inline SVG in rendered DOM | Header | Moon icon | Vector; source markup archived | REVIEW |
| [svg-2.svg](assets/svg-2.svg) | Inline SVG in rendered DOM | Mobile nav | Menu icon | Vector; source markup archived | REVIEW |
| [svg-3.svg](assets/svg-3.svg) | Inline SVG in rendered DOM | Footer | Location | Vector; source markup archived | REVIEW |
| [svg-4.svg](assets/svg-4.svg) | Inline SVG in rendered DOM | Footer | Telephone | Vector; source markup archived | REVIEW |
| [svg-5.svg](assets/svg-5.svg) | Inline SVG in rendered DOM | Footer | Email | Vector; source markup archived | REVIEW |
| [svg-6.svg](assets/svg-6.svg) | Inline SVG in rendered DOM | Background | Animated organic shape | Vector; source markup archived | REVIEW |
| [arabic-logo.png](assets/arabic-logo.png) | Arabic DOM data:image/png base64 | Arabic header | Brand lockup | 204×72 raster; request vector master | REVIEW |

## Other media / resources
- YouTube video https://www.youtube.com/watch?v=qCeML7rAjkk — About; company video; REVIEW for relevance, rights, captions and accessible title. Embedded iframe URL and channel are preserved in evidence; video not downloaded.
- /logo192.png — apple-touch-icon declared in head; not returned by asset bundling; quality/load status unverified. REVIEW.
- Cairo font family via archived Google Fonts stylesheet; weights 200–1000 requested. No binary font file discovered by the browser inventory. REVIEW subsets/licensing before future hosting.
- main.7903fa75.js — script reference inventoried, not executed outside browser or archived as a redesign deliverable. Existing rendering is client-side React (create-react-app marker). REVIEW migration needs later.
- No linked PDFs, downloads or client-logo collection was discovered. Theme banners must not be described as partners or clients.
- Inline close icon appears in mobile menu; its visible function was inspected. Default-state inline SVG export covers six listed symbols; no claim of an exhaustive icon library.

Asset previews: evidence/asset-contact-sheet.jpg. Banner words and service image titles are transcribed in content/raw/media.md. Export metadata with original URLs is in evidence/asset-bundle-result.json. Asset checksums are in evidence/asset-checksums.json.

## Exact banner mapping

01 Thinking; 02 Technology; 03 Education; 04 التفكير; 05 التقنية; 06 التعليم. Visual review of the archived contact sheet confirmed these labels.
